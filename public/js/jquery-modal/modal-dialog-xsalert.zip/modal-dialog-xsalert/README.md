<img width="684" alt="xsalert" src="https://user-images.githubusercontent.com/39766031/170674914-b3d1bc26-0b48-4ad7-94fc-21c1da76d2b9.png">


# XSAlert

## An easy-to-use, responsive and customizable JavaScript (jQuery) Alert

Check out Documentation and exampels at https://xsgames.co/xsalert

## Some examples:

<img width="533" alt="xsalert1" src="https://user-images.githubusercontent.com/39766031/170674252-b8803938-1a17-46c3-9300-386c204a7558.png">
<img width="521" alt="xsalert2" src="https://user-images.githubusercontent.com/39766031/170674617-298b0ac6-ed26-4dd2-8dcd-2c06728279fa.png">
<img width="518" alt="xsalert3" src="https://user-images.githubusercontent.com/39766031/170674626-5c0db18b-786b-458a-b0b4-a3d6cb047615.png">
<img width="529" alt="xsalert4" src="https://user-images.githubusercontent.com/39766031/170674629-7a4ce8b0-2478-4876-885f-e4064cb777cc.png">

